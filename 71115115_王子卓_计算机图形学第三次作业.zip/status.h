#ifndef STATUS_H
#define STATUS_H
#include <QString>

class Status
{
public:
    Status();
    QString status;
};
#endif // STATUS_H
