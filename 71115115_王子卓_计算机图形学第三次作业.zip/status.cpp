#include "status.h"

Status::Status()
{
    status = "select";
}
